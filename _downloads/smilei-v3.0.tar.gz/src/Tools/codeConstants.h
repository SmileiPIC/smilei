#ifdef CODECONSTANT_H
#define CODECONSTANT_H

//! \todo{define PI and other constants here}

#endif
